# inft1016_itf_202203_practicals

Vo Tran Trong Nghia
git config --global user.name Vo Tran Trong Nghia
git config --global user.email nghia1223n@gmail.com
